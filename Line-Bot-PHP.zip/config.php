<?php
	$sUsername = 'b5c37df8f2ad55';
	$sPassword = 'cfa0b270';
	$sHost = 'us-cdbr-iron-east-03.cleardb.net';
	$sDb = 'heroku_c567de8b5a4ca4f';
?> 